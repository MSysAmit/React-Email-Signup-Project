const errors = require('restify-errors');
const UserData = require('../models/Users');
const nodemailer = require('nodemailer');
const restify = require('restify');

module.exports = server => {
    server.post('/users', (req, res) => {
            console.log(req.body)
            console.log("email-id is",req.body.email)
            doc = new UserData({ fname: req.body.fname, lname: req.body.lname, email:req.body.email, password:''})
            doc.save();
            console.log("Doc!!!!!!!!!!!!!! email is ", doc.email)
            sendEmail(req);
        })

        server.post('/loginuser', (req, res) => {
            let {email, password} = req.body;
            
            UserData.findOne({email: email},(err, userData) => {
                console.log('userdata in login',userData);
                console.log('err in login',err);
                  if (!err && userData != null) {
                      console.log("inside");
                      let passwordCheck = (password == userData.password);
                      console.log("Login password provided  is+++++++++++", password);
                      console.log("Login password  from database is +++++++++++++++", userData.password);
                      if (passwordCheck) { 
                             results = 'You are logged in, Welcome!'
                             console.log('You are logged in, Welcome!')
                             res.send(JSON.stringify(results));
                      } else {
                        results = 'incorrect password'
                        console.log('incorrect password');
                        res.send((results));
                      }
                  } else {
                    results = 'invalid login credentials'
                    console.log('invalid login credentials');
                    res.send((results));
                    
                  }
              })
          })
        server.put('/register', (req, res) => {
            console.log("email is:", req.body.email )
            console.log("password is",req.body.password)
                doc.password = req.body.password
            doc.save();
        })

    //    function makeid() {
    //         var text = "";
    //         var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
          
    //         for (var i = 0; i < 6; i++)
    //           text += possible.charAt(Math.floor(Math.random() * possible.length));
          
    //         return text;
    //       }
       

        var transporter = nodemailer.createTransport({
          service: 'gmail',
          auth: {
            user: 'amitmsysreact@gmail.com',
            pass: 'AmitMsys@#'
          }
        });
       
    function sendEmail(req){
        // const passcode = makeid();
        var mailOptions = {
          from: 'amichandan08@gmail.com',
          to: req.body.email,
          subject: 'Sending Email using Node.js',
          text: 'You are receiving this because you (or someone else) have requested the set of the password for your account.\n\n' +
          'Please click on the following link, or paste this into your browser to complete the process:\n\n' +
          'http://192.168.2.20:3000/setPassword' + '\n\n' +
          'If you did not request this, please ignore this email.\n'
      };
        
        transporter.sendMail(mailOptions, function(error, info){
          if (error) { 
            console.log(error);
          } else {
            console.log('Email sent: ' + info.response);
            
          }
        });

    }


};