const mongoose = require('mongoose');
const timestamp = require('mongoose-timestamp');


const UserTable = new mongoose.Schema({
    fname: {
        type: String,
        required: true,
    },
    lname: {
        type: String,
        required: true,
    },
    email: {
       type: String,
    },
    password: {
        type: String,
     }
});


  

UserTable.plugin(timestamp);

const UserData = mongoose.model('UserData', UserTable);
module.exports = UserData;