import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';
import { Route, Switch, Redirect, Link, BrowserRouter as Router } from 'react-router-dom'
import SetPassword from './SetPassword';
import Login from './Login'



const routing = (
  <Router>
    <Switch>
    
      <Route exact path="/" component={App} />
      <Route path="/SetPassword" component={SetPassword} />
      <Route path="/Login" component={Login} />
    
    </Switch>
  </Router>
)


ReactDOM.render(
  routing,
  document.getElementById('root') || document.createElement('div'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: http://bit.ly/CRA-PWA
serviceWorker.unregister();
