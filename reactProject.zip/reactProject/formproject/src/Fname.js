import React, { Component } from 'react';
class FnameInput extends Component {
  render() {
    return (<input type="text" {...this.props} />)
    
  }
}

export default FnameInput;