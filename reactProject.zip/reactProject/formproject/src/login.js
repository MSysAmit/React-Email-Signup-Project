import React, { Component } from 'react';
import axios from 'axios'
import PasswordInput from './Password'
import EmailInput from './Email'
class Login extends Component {
  constructor() {
    super();
    this.state = {
      email: '',
      password: '',
      submit: false,
      responseData: '',
      invalid: false,
    }
  }

  onChange = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  }

  onSubmit = (e) => {
    e.preventDefault();
    const { email, password, responseData } = this.state;
    if (email != '' && password != '') {
      axios.post('/loginuser', { email, password })
        .then((response) => {
          console.log("The database data response is", response.data);
          this.setState({ responseData: response.data });
          // alert(response.data);
          if (response.data === "incorrect password" || response.data === "invalid login credentials") {
            this.setState({ invalid: true })
            alert(response.data);
          }
          else {
            this.setState({
              submit: true,
              invalid: false
            });
          }
        }).catch();
    }
    else {
      alert("Please fill email and password");
      this.setState({
        submit: false,
        invalid: true
      });
    }
    this.setState({
      password: '',
      email: ''
    });
  }

  render() {
    const { submit, email, password, invalid } = this.state;
    return (
      <div>
        {(submit === true && invalid === false) ? <p>You have succesfully Logged in!!!!</p> :
          // <form className="formMainApp" onSubmit={this.onSubmit} name="loginForm">
          //   <div className="appDiv">
          //     <label id="email-label">Email: &nbsp;</label>
          //     <input
          //       type="text"
          //       name="email"
          //       value={email}
          //       onChange={this.onChange}
          //       aria-labelledby="email-label"
          //     />
          //   </div>
          //   <div className="appDiv">
          //     <label id="password-label">Password:&nbsp; </label>
          //     <input
          //       type="text"
          //       name="password"
          //       value={password}
          //       onChange={this.onChange}
          //       aria-labelledby="password-label"
          //     />

          //   </div>
          //   <button className="submitButton" type="submit" name="Submit">submit</button>
          // </form>}

          <div className="formMainApp">
            <h3>Please enter credentials.</h3>
            <div className="appDiv">
              Email:
            <EmailInput
                label="Email"
                id="input-auth-email"
                name="email" className="marginLeft10"
                value={this.state.email}
                onChange={this.onChange} />
            </div>
            <div className="appDiv">
              Password:
          <PasswordInput
                label="Password"
                id="input-auth-password"
                name="password" className="marginLeft3"
                value={this.state.password}
                onChange={this.onChange}
              />
            </div>
            <div>
              <button type="submit" className="submitButton" onClick={this.onSubmit}>Submit</button>
            </div>
          </div>}
      </div>
    )
  }
}

export default Login;