import React, { Component } from 'react';
class LnameInput extends Component {
  render() {
    return (<input type="text" {...this.props} />)
    
  }
}

export default LnameInput;