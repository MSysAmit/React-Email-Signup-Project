import React, { Component } from 'react';
class PasswordInput extends Component {
  render() {
    return (<input type="text" {...this.props} />)
    
  }
}

export default PasswordInput;