import React, { Component } from 'react';
import axios from 'axios';
import SetPassword from './SetPassword';
import './App.css';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import Fname from './Fname'
import Lname from './Lname'
import EmailInput from './Email'



class App extends Component {
  constructor() {
    super();
    this.state = {
      fname: '',
      lname: '',
      email: '',
      sub: false
    };
  }

  onChange = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  }

  onSubmit = (e) => {
    e.preventDefault();
    const { fname, lname, email } = this.state;
    axios.post('/users', { fname, lname, email })
      .then((result) => {
        console.log("result is", result)
      });

    this.setState({
      fname: '',
      lname: '',
      email: '',
      sub: true
    });


  }

  render() {
    const { fname, lname, email, sub } = this.state;

    return (

      <div>


        {/* {sub ? <p>An email has been send to your mailid for setting password. Please set the password.</p>:
          <form className="formMainApp" onSubmit={this.onSubmit} name="userDetailsForm">
            <div className="appDiv">
              <label>FirstName: &nbsp;</label>
              <input
                type="text"
                name="fname"
                value={fname}
                onChange={this.onChange}
              />
            </div>
            <div className="appDiv">
              <label>LastName:&nbsp;</label>
              <input
                type="text"
                name="lname"
                value={lname}
                onChange={this.onChange}
              />
            </div>
            <div className="appDiv">
              <label>Email:&nbsp;</label>
              <input className="emailInput"
                type="text"
                name="email"
                value={email}
                onChange={this.onChange}
              />
            </div>
            <button className="submitButton" type="submit">Submit</button>
          </form>} */}

        {
          sub ? <p>An email has been send to your mailid for setting password. Please set the password.</p> :
            <div className="formMainApp">
              <h3>Please enter the details.</h3>
              <div className="appDiv">
              FirstName:
              <Fname
                label="Fname"
                name="fname" className="marginLeft3"
                value={this.state.fname}
                onChange={this.onChange}
              />
              </div>
              <div className="appDiv">
              LastName:
              <Lname
                label="Lname" className="marginLeft3"
                name="lname"
                value={this.state.lname}
                onChange={this.onChange}
              />
              </div>
              <div className="appDiv">
              Email:
              <EmailInput
                label="Email" className="marginLeft10"
                name="email"
                value={this.state.email}
                onChange={this.onChange}
              />
              </div>
              <div>
              <button className="submitButton" type="submit" onClick={this.onSubmit}>Submit</button>
              </div>
            </div>

        }

      </div>

    )
  }
}


export default App;