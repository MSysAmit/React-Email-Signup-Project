import React, { Component } from 'react';
import axios from 'axios';
import Login from './Login';
import './App.css'
import { Link } from 'react-router-dom';
import PasswordInput from './Password'

class SetPassword extends Component {
  constructor(props) {
    super(props);
    this.state = {
      password: '',
      submit: false
    }
  }
    onChange = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  }
    onSubmit = (e) => {
    e.preventDefault();
    const { password} = this.state;
     axios.put('/register', {password })
      .then((result) => {
        console.log("result is", result)
      });
     this.setState({
      password: '',
      submit: true
    })
  }

  render() {
    const { password, submit } = this.state;
    // return (
    //   <div className="submitPassword">
    //     {submit ? <Login /> :
    //       <form className="formMainSetPassword formMainApp" onSubmit={this.onSubmit} name="setPasswordForm">
    //         <div className="appDiv">
    //           <label>password:&nbsp;</label>
    //           <input
    //             type="text"
    //             name="password"
    //             value={password}
    //             onChange={this.onChange}
    //           />
    //         </div>
    //         <button className="submitButton" type="submit">Submit</button>
    //       </form>
    //     }

    //   </div>
    // )

    return(
      <div >
        {submit ? <Login/> :
          <div className="formMainApp">
            <h3>Please Set the password.</h3>
            <div className="appDiv">
            Password:
            <PasswordInput
            className="marginLeft3"
             label="Password"
             name="password"
             value={this.state.password}
             onChange={this.onChange}
           />
           </div>
           <div>
        <button type="submit" className="submitButton" onClick={this.onSubmit}>Submit</button>
        </div>
        </div>
        }
      </div>
    )
  }
}

export default SetPassword;