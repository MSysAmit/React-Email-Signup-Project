import React from "react";
import { shallow, mount } from "enzyme";
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import SetPassword from '../SetPassword';
Enzyme.configure({ adapter: new Adapter() });



describe('<SetPassword />', () => {
   it('renders one time <login /> component', () => {
       const component = shallow(<SetPassword/>);
       expect(component).toHaveLength(1);
   });
   describe('it updates the submit value to true on button click', () => {
       const component = mount(<SetPassword />);
       const button = component.find('button');
       button.simulate('click');
       expect(component.state().submit).toEqual(true);
   });
   it("renders correctly", () => {
       const component = shallow(
           <setPassword password = "kumar"/>
       );
       expect(component).toMatchSnapshot();
   })

  });