import React from "react";
import { shallow, mount } from "enzyme";
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import Login from '../Login';
Enzyme.configure({ adapter: new Adapter() });


describe('<Login />', () => {
   it('renders one time <login /> component', () => {
       const component = shallow(<Login/>);
       expect(component).toHaveLength(1);
   });
   describe('it updates the submit value to true on button click', () => {
       const component = mount(<Login />);
       const button = component.find('button');
       button.simulate('click');
       expect(component.state().submit).toEqual(false);
   });
   it("renders correctly", () => {
       const component = shallow(
           <Login email = "amichandan080@gmail.com" password = "kumar"/>
       );
       expect(component).toMatchSnapshot();
   });
//    it("renders correctly", () => {
//     const component = shallow(
//         <Login email = "amit.kumar@msystechnologies.com" password = "b@b"/>
//     );
//     const button = component.find('button');
//        console.log("Here is my button",button.props());
//        button.simulate('click', {
//         preventDefault: () => {
//         }
//        });
//        console.log("My component state is", component.state())
//        expect(component.state().submit).toEqual(true);
//     });

       it("it calls axios and return alert", () => {
           const response = Login('email = "amit.kumar@msystechnologies.com" password = "b@b"');
           console.log("The response data is", response);
       })








  });
