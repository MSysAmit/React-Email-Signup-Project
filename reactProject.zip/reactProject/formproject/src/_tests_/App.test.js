import React from "react";
import { shallow, mount } from "enzyme";
import App from "../App";
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
Enzyme.configure({ adapter: new Adapter() });

describe('<App />', () => {
   it('renders 1 <App /> component', () => {
       const component = shallow(<App/>);
       expect(component).toHaveLength(1);
   });
   describe('it updates the submit value to true on button click', () => {
       const component = mount(<App />);
       const button = component.find('button');
       button.simulate('click');
       expect(component.state().sub).toEqual(true);
   });
   it("renders correctly", () => {
       const component = shallow(
           <App fname = "Amit" lname = "kumar" email = "amichandan080@gmail.com" />
       );
       expect(component).toMatchSnapshot();
   })

//    describe('it renders "An email has been send to your mailid for setting password. Please set the password." on button click', () => {
//     const component = mount(<App />);
//     const button = component.find('button');
//     console.log("Here is my button",button.props());
//     button.simulate('click');
//     console.log("My component state is", component.state())
//     const text = component.find('<p/>')
//     expect(text).toEqual("An email has been send to your mailid for setting password. Please set the password.");
//    });


});


