const restify = require('restify');
var mongoose = require('mongoose');

const server = restify.createServer();

const PORT = process.env.PORT || 3001
server.use(restify.plugins.bodyParser());

server.listen(`${PORT}`, () => {
    mongoose.connect('mongodb://myUserAdmin:abc123@localhost:27017');
});

const db = mongoose.connection;
db.on('error', (err) => console.log(err));

db.once('open', () => {
    require('./routes/users')(server);
    console.log(`Server started on port ${PORT}`);
});








// mongoose.connect('mongodb://myUserAdmin:abc123@localhost:27017');
// const Message = mongoose.model('Message', {fname: String,
//     lname: String,
//     email: String,
//     password: String})

// const express = require('express')
// const bodyParser = require('body-parser')
// const nodemailer = require('nodemailer')


// const app = express()

// app.use(bodyParser.json())
// app.use(bodyParser.urlencoded({extended: false}))
// var doc;
// app.post('/api/form', (req, res) => {
//     console.log(req.body)
//     console.log("email-id is",req.body.email)
//     doc = new Message({ fname: req.body.fname, lname: req.body.lname, email:req.body.email, password:''})
//     doc.save();
//     console.log("Docs email is ", doc.email)
//     //sendEmail(doc.email);
// })


// const PORT = process.env.PORT || 3001

// app.listen(PORT, () => {
//     console.log(`Server is listning on port ${PORT}`)
// })



// var transporter = nodemailer.createTransport({
//   service: 'gmail',
//   auth: {
//     user: 'amichandan08@gmail.com',
//     pass: 'Ri2g79n7@#'
//   }
// });


// function sendEmail(email){
//     var mailOptions = {
//         from: 'amichadan08@gmail.com',
//         to: email,
//         subject: 'Set Password for Amit Application',
//         text: 'Hi This Is amit!. Below the link provided for setting the password Please click on the link and set the password'
               
//       };
      
      
//         transporter.sendMail(mailOptions, function(error, info){
//             if (error) {
//               console.log(error);
//             } else {
//               console.log('Email sent: ' + info.response);
//             }
//           });
// }


  

